export interface AuthResponse {
email: string;
password : string;
}
